#!/usr/bin/env bash
# Setup GitHub Actions secrets via GitHub CLI (gh)
# Usage: ./setup_secrets.sh <owner/repo>

set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 <owner/repo>"
  exit 1
fi

REPO="$1"

echo "Setting secrets for $REPO ..."
read -p "FIREBASE_SERVICE_ACCOUNT (paste JSON then Enter): " -r FIREBASE_SERVICE_ACCOUNT
read -p "FIREBASE_PROJECT_ID [able-winter-463510-t8]: " -r FIREBASE_PROJECT_ID
FIREBASE_PROJECT_ID=${FIREBASE_PROJECT_ID:-able-winter-463510-t8}
read -p "VERCEL_TOKEN: " -r VERCEL_TOKEN
read -p "VERCEL_ORG_ID: " -r VERCEL_ORG_ID
read -p "VERCEL_PROJECT_ID: " -r VERCEL_PROJECT_ID
read -p "PLAY_JSON_KEY (paste JSON then Enter): " -r PLAY_JSON_KEY
read -p "PLAY_PACKAGE_NAME (e.g. com.aikya.app): " -r PLAY_PACKAGE_NAME

gh secret set FIREBASE_SERVICE_ACCOUNT --repo "$REPO" --body "$FIREBASE_SERVICE_ACCOUNT"
gh secret set FIREBASE_PROJECT_ID --repo "$REPO" --body "$FIREBASE_PROJECT_ID"
gh secret set VERCEL_TOKEN --repo "$REPO" --body "$VERCEL_TOKEN"
gh secret set VERCEL_ORG_ID --repo "$REPO" --body "$VERCEL_ORG_ID"
gh secret set VERCEL_PROJECT_ID --repo "$REPO" --body "$VERCEL_PROJECT_ID"
gh secret set PLAY_JSON_KEY --repo "$REPO" --body "$PLAY_JSON_KEY"
gh secret set PLAY_PACKAGE_NAME --repo "$REPO" --body "$PLAY_PACKAGE_NAME"

echo "✅ Secrets set."
echo "Next: commit + push files to main to trigger the workflow."