# Web‑Only All‑Push (No Terminal Needed)

## 1) Upload the Pack
- Go to your GitHub repo (default branch: `main`).
- Click **Add file → Upload files**.
- Drag‑drop the contents of `aikya_all_push_pack.zip` (not the zip itself) into the root.
- Commit directly to `main`.

## 2) Add Secrets (GitHub → Settings → Secrets and variables → Actions → New repository secret)
Paste values exactly (no quotes).

- FIREBASE_SERVICE_ACCOUNT → full JSON of your Firebase service account
- FIREBASE_PROJECT_ID → able-winter-463510-t8
- VERCEL_TOKEN → your Vercel personal token
- VERCEL_ORG_ID → your Vercel team/org id
- VERCEL_PROJECT_ID → your Vercel project id
- PLAY_JSON_KEY → Google Play service account JSON (plain text)
- PLAY_PACKAGE_NAME → e.g. com.aikya.app

## 3) Confirm Workflow
- Go to **Actions** tab → select **Aikya All-Push Autopilot** → see the run start automatically.
- On success:
  - Firebase Hosting deploys (map to **aikya.ink** in Firebase Hosting if not already).
  - Vercel deploys (map to **aikya.space** in Vercel Domain settings).
  - If a `.aab` exists, it uploads to Google Play (production).