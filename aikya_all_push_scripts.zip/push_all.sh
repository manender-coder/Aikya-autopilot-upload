#!/usr/bin/env bash
# Commit and push the All-Push pack to your repo
# Usage: ./push_all.sh <repo-dir>

set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 <repo-dir>"
  exit 1
fi

DIR="$1"
cd "$DIR"

git add .
git commit -m "Aikya All-Push Autopilot Init"
git push origin main

echo "✅ Pushed to main. GitHub Actions will start the All-Push pipeline."