# Aikya Operator (Pure‑Auto Hourly)
Runs hourly (and on push) to normalize audio, upload to YouTube, and optionally trigger deploys/broadcasts.

## Files
- `.github/workflows/aikya-operator.yml` — CI pipeline (hourly + manual + on push)
- `scripts/youtube_device_auth.mjs` — first‑run device flow; saves YT refresh token to repo secrets
- `scripts/operator.mjs` — autonorms + YouTube upload (expand to IG/WA as needed)

## Secrets (Repo → Settings → Secrets → Actions)
- `SERVICE_ACCOUNT_JSON` (Firebase service account JSON as one line)
- `YT_CLIENT_ID` and `YT_CLIENT_SECRET` (from your OAuth client)
- `GH_TOKEN` (Personal Access Token with `repo` scope)
- (Optional) `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`
- (Optional) `IG_USER_ID`, `IG_ACCESS_TOKEN`, `WHATSAPP_TOKEN`

## Usage
1. Add secrets, commit these files to `main`.
2. First run prints a device code — enter it once; the refresh token is saved automatically.
3. Put your newest audio/video under `content/`. The job picks the latest file each hour.
4. Extend `scripts/operator.mjs` for captions before upload, IG/WhatsApp posts, etc.
