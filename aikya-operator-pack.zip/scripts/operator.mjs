import {google} from 'googleapis';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegPath from 'ffmpeg-static';
import fs from 'node:fs';
import path from 'node:path';
import got from 'got';

ffmpeg.setFfmpegPath(ffmpegPath);

// Pick newest file under content/
const CONTENT_DIR = 'content';
const OUT_DIR = 'build';
fs.mkdirSync(OUT_DIR, { recursive: true });

function newestAsset() {
  if (!fs.existsSync(CONTENT_DIR)) throw new Error(`No ${CONTENT_DIR}/ folder found.`);
  const files = fs.readdirSync(CONTENT_DIR).map(f => path.join(CONTENT_DIR, f))
    .filter(p => fs.statSync(p).isFile());
  if (!files.length) throw new Error('No assets in content/');
  return files.map(p => ({ p, m: fs.statSync(p).mtimeMs }))
    .sort((a,b)=>b.m-a.m)[0].p;
}

const input = newestAsset();
const out = path.join(OUT_DIR, 'normalized.mp3');

// 1) Autonorms
await new Promise((res, rej) =>
  ffmpeg(input)
    .audioFilter(['loudnorm=I=-16:TP=-1.5:LRA=11'])
    .audioCodec('libmp3lame')
    .outputOptions(['-b:a 192k'])
    .save(out).on('end', res).on('error', rej)
);

// 2) YouTube upload
const oauth = new google.auth.OAuth2(process.env.YT_CLIENT_ID, process.env.YT_CLIENT_SECRET);
oauth.setCredentials({ refresh_token: process.env.YT_REFRESH_TOKEN });
const yt = google.youtube({version: 'v3', auth: oauth});

const title = 'Aikya Bhakti • Live Kirtan';
const description = 'Auto-uploaded by Aikya Operator ♾️';

const uploadRes = await yt.videos.insert({
  part: ['snippet','status'],
  requestBody: { snippet: { title, description }, status: { privacyStatus: 'public' } },
  media: { body: fs.createReadStream(out) }
});
const videoId = uploadRes.data.id;
console.log('🎬 YouTube uploaded:', `https://youtu.be/${videoId}`);

console.log('✅ Operator cycle complete.');