import 'dotenv/config';
import {google} from 'googleapis';
import sodium from 'libsodium-wrappers';
import got from 'got';

const {
  YT_CLIENT_ID, YT_CLIENT_SECRET, YT_REFRESH_TOKEN,
  GH_PAT, GITHUB_REPOSITORY
} = process.env;

if (YT_REFRESH_TOKEN && YT_REFRESH_TOKEN.trim() !== '') {
  console.log('YT refresh token already present. Skipping auth.');
  process.exit(0);
}

const deviceCodeRes = await got.post('https://oauth2.googleapis.com/device/code', {
  form: {
    client_id: YT_CLIENT_ID,
    scope: 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube'
  }
}).json();

console.log(`🔑 Visit ${deviceCodeRes.verification_url} and enter code: ${deviceCodeRes.user_code}`);
console.log('Waiting for approval (one-time step)…');

let token;
while (true) {
  await new Promise(r => setTimeout(r, deviceCodeRes.interval * 1000));
  try {
    token = await got.post('https://oauth2.googleapis.com/token', {
      form: {
        client_id: YT_CLIENT_ID,
        client_secret: YT_CLIENT_SECRET,
        device_code: deviceCodeRes.device_code,
        grant_type: 'urn:ietf:params:oauth:grant-type:device_code'
      }
    }).json();
    if (token.refresh_token) break;
  } catch (e) {
    const body = e.response?.body || '';
    if (!body.includes('authorization_pending')) throw e;
  }
}
const refresh = token.refresh_token;
console.log('✅ Received YouTube refresh token. Saving to repo secrets…');

// Save YT_REFRESH_TOKEN to repo secrets
const [owner, repo] = GITHUB_REPOSITORY.split('/');

// 1) Get public key
const keyData = await got.get(`https://api.github.com/repos/${owner}/${repo}/actions/secrets/public-key`, {
  headers: { Authorization: `Bearer ${GH_PAT}`, 'User-Agent': 'aikya-operator' }
}).json();

await sodium.ready;
const binkey = sodium.from_base64(keyData.key, sodium.base64_variants.ORIGINAL);
const enc = sodium.crypto_box_seal(Buffer.from(refresh), binkey);
const encrypted_value = Buffer.from(enc).toString('base64');

// 2) PUT secret
await got.put(`https://api.github.com/repos/${owner}/${repo}/actions/secrets/YT_REFRESH_TOKEN`, {
  headers: { Authorization: `Bearer ${GH_PAT}`, 'User-Agent': 'aikya-operator' },
  json: { encrypted_value, key_id: keyData.key_id }
});

console.log('🔒 Secret YT_REFRESH_TOKEN updated.');