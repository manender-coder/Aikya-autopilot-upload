# Aikya All-Push Final (Error-Proof)

Copy `all-push-final.yml` to `.github/workflows/` and commit to `main`.

## Secrets
- Firebase (optional): `FIREBASE_SERVICE_ACCOUNT`, `FIREBASE_PROJECT_ID`
- Vercel (recommended): `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`
- Google Play (optional): `PLAY_JSON_KEY`, `PLAY_PACKAGE_NAME`

Triggers: push to main, manual run, every 6 hours.
