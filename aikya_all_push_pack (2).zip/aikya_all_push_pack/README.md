# Aikya All-Push Autopilot Pack

This pack sets up a single **All-Push** CI/CD pipeline: **GitHub → Firebase → Vercel → Google Play**.

## 1) Add GitHub Secrets (Repository → Settings → Secrets and variables → Actions → New repository secret)

Required:
- `FIREBASE_SERVICE_ACCOUNT`  → JSON from your Firebase service account (provided earlier)
- `FIREBASE_PROJECT_ID`       → `able-winter-463510-t8`
- `VERCEL_TOKEN`              → Personal token from Vercel
- `VERCEL_ORG_ID`             → Your Vercel org/team id
- `VERCEL_PROJECT_ID`         → Your Vercel project id (optional but recommended)
- `PLAY_JSON_KEY`             → Google Play service account JSON (as plain text)
- `PLAY_PACKAGE_NAME`         → e.g. `com.aikya.app`

## 2) Commit these files to the root of your repo (default branch: `main`)
- `.github/workflows/all-push.yml`
- `firebase.json`
- `.firebaserc`
- `vercel.json`
- `fastlane/` (optional if using Fastlane)

## 3) Push to `main`
This triggers the **All-Push** workflow automatically.

- If a `.aab` file exists anywhere in the repo, it will be uploaded to **Google Play (production)**.
- If `firebase.json` is present, **Firebase Hosting** deploys to project `able-winter-463510-t8` (domain: `aikya.ink` when mapped).
- Vercel deploy runs via CLI using `VERCEL_TOKEN` and your org scope (domain: `aikya.space` when mapped).

### Notes
- `public` directory for Firebase is set to `dist`. Change it to your build output folder if different (e.g., `build`, `.next`, `out`).
- Vercel autodetects frameworks via `package.json`. If not using Next.js, adjust `vercel.json` builds accordingly.
- The workflow is resilient: steps skip gracefully if related files don’t exist.

## Verify
- Firebase hosting: https://aikya.ink (after DNS + site mapping)
- Vercel: https://aikya.space (after project linkage)

**One commit → All systems push.**