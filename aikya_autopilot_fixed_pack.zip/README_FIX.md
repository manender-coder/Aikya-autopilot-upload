
# Aikya Autopilot — FIXED Pack

**Files**
- `.github/workflows/aikya-all-push-final.yml`
- `.github/workflows/charevati-autocron.yml`

**Install**
1) Remove/rename broken workflows (errors like `Unexpected value` or `No event triggers defined`).  
2) Add the two files above, commit to `main`.  
3) Ensure secrets: `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`. Optional Firebase (`FIREBASE_SERVICE_ACCOUNT` or `FIREBASE_SA_JSON` + `FIREBASE_PROJECT_ID`) and Play (`PLAY_JSON_KEY`, `PLAY_PACKAGE_NAME`).  
4) Set Vercel runtime env `OPENAI_API_KEY` (ALL CAPS).

Autocron re-triggers all-push every 30 minutes. Missing services are skipped; runs should pass.
