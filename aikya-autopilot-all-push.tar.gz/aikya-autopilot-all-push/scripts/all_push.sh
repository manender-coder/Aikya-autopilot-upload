#!/usr/bin/env bash
set -euo pipefail

echo "[1/4] Git pull & build"
if [ -f package.json ]; then
  if command -v yarn >/dev/null 2>&1 && [ -f yarn.lock ]; then
    yarn install --frozen-lockfile
    yarn build || true
  else
    npm ci || npm i
    npm run build || true
  fi
fi

echo "[2/4] Vercel deploy"
if command -v vercel >/dev/null 2>&1; then
  vercel pull --yes --environment=production --token="$VERCEL_TOKEN"
  vercel build --prod --token="$VERCEL_TOKEN"
  vercel deploy --prebuilt --prod --token="$VERCEL_TOKEN"
else
  echo "Vercel CLI not found. Install with: npm i -g vercel"
fi

echo "[3/4] Firebase deploy"
if command -v firebase >/dev/null 2>&1; then
  echo "$FIREBASE_SERVICE_ACCOUNT" > firebase-sa.json
  firebase deploy --only hosting --project "$FIREBASE_PROJECT_ID" --token "$(cat firebase-sa.json)"
else
  echo "Firebase CLI not found. Install with: npm i -g firebase-tools"
fi

echo "[4/4] Google Play upload"
if [ -d android ]; then
  (cd android && ./gradlew bundleRelease || true)
  if command -v fastlane >/dev/null 2>&1; then
    (cd fastlane/android && fastlane play_release) || true
  else
    echo "Fastlane not found. Install Ruby and fastlane to upload."
  fi
else
  echo "No android folder; skipping Play upload."
fi

echo "ALL-PUSH COMPLETE ✅"
