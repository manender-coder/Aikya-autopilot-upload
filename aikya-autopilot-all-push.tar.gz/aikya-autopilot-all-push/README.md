# Aikya Autopilot All-Push (Starter)

**One-click CI/CD** across Vercel (aikya.space), Firebase (aikya.ink), and Google Play (Android).

## Quick Start
1. Commit this repo root to your project.
2. Set GitHub Secrets (Repo → Settings → Secrets and variables → Actions):
   - `FIREBASE_PROJECT_ID` = able-winter-463510-t8
   - `FIREBASE_SERVICE_ACCOUNT` = contents of service account JSON
   - `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`
   - `PLAY_SERVICE_ACCOUNT_JSON` = Play Console JSON (service account)
   - `PLAY_PACKAGE_NAME` = e.g. `com.aikya.app`
3. Push to `main` or click **Actions → Aikya All-Push → Run workflow**.

## Local All-Push
Export env vars then run:
```bash
export FIREBASE_PROJECT_ID=able-winter-463510-t8
export FIREBASE_SERVICE_ACCOUNT='{"type":"service_account",...}'
export VERCEL_TOKEN=***
export VERCEL_ORG_ID=***
export VERCEL_PROJECT_ID=***
export PLAY_SERVICE_ACCOUNT_JSON='{"type":"service_account",...}'
export PLAY_PACKAGE_NAME=com.aikya.app
bash scripts/all_push.sh
```

## Notes
- `firebase.json` and `.firebaserc` are included; adjust hosting target/public dir as needed.
- `vercel.json` is generic for Next.js or static builds; adapt if using a different stack.
- Android upload requires `android/` present and a release keystore configured.
